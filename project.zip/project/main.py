#!/usr/local/bin/python
from cProfile import label
import os, sys

#importing external libraries
from pathlib import Path
from xml.dom import NO_MODIFICATION_ALLOWED_ERR
from logzero import logger, logfile
from sense_hat import SenseHat
from picamera import PiCamera
from orbit import ISS
from time import sleep
from datetime import datetime, timedelta
import csv

from PIL import Image
from pycoral.adapters import common
from pycoral.adapters import classify
from pycoral.utils.edgetpu import make_interpreter
from pycoral.utils.dataset import read_label_file

#ndvi import libraries
import cv2
import numpy as np
from fastiecm import fastiecm
from time import sleep


#functions

#create a CSV file
def create_csv_file(data_file):
    """Create a new CSV file and add the header row"""
    with open(data_file, 'w') as f:
        writer = csv.writer(f)
        header = ("Counter", "Date/time", "Latitude", "Longitude", "Mag_x",  "Mag_y", "Mag_z", "Label1", "Label2")
        writer.writerow(header)

#add datas in the file
def add_csv_data(data_file, data):
    """Add a row of data to the data_file CSV"""
    with open(data_file, 'a') as f:
        writer = csv.writer(f)
        writer.writerow(data)

#convert a skyfield angle to an exif representation
#returns a tuple containing a boolean (to indicate if the angle is negative) and the converted angle
def convert(angle):
  
    sign, degrees, minutes, seconds = angle.signed_dms()
    exif_angle = f'{degrees:.0f}/1,{minutes:.0f}/1,{seconds*10:.0f}/10'
    return sign < 0, exif_angle


#use the camera to capture the images
def capture(camera, image):
    location = ISS.coordinates()

    #convert the latitude and longitude to EXIF-appropriate representations
    south, exif_latitude = convert(location.latitude)
    west, exif_longitude = convert(location.longitude)

    #set the EXIF tags specifying the current location
    camera.exif_tags['GPS.GPSLatitude'] = exif_latitude
    camera.exif_tags['GPS.GPSLatitudeRef'] = "S" if south else "N"
    camera.exif_tags['GPS.GPSLongitude'] = exif_longitude
    camera.exif_tags['GPS.GPSLongitudeRef'] = "W" if west else "E"

    #capture the image
    camera.capture(image)
    
#modifies the pixel values of the image
def contrast_stretch(im):
    in_min = np.percentile(im, 5)
    in_max = np.percentile(im, 95)
    
    out_min = 0.0
    out_max = 255.0
    
    out = im - in_min
    out *= ((out_min - out_max) / (in_min - in_max))
    out += in_min

    return out

#calculate the nvdi image with the rbg code
def calc_ndvi(image):
    b, g, r = cv2.split(image)
    bottom = (r.astype(float) + b.astype(float))
    bottom[bottom==0] = 0.01
    ndvi = (r.astype(float) - b) / bottom
    return ndvi


#start of the program

#the string that contains the name of the folder where the file is
base_folder = Path(__file__).parent.resolve()

# create the file events.log in base_folder
logfile(base_folder/"events.log")

#constructor of the SenseHat class
sense = SenseHat()

#constructor of the PiCamera class
cam = PiCamera()
cam.resolution = (2272, 1704)


# Initialise the CSV file
data_file = base_folder/"data.csv"
create_csv_file(data_file)  

# Initialise the photo counter 
counter = 1

# Record the start and current time
start_time = datetime.now() 
now_time = datetime.now()
script_dir = Path(__file__).parent.resolve()


#import the sea model
model_sea_file = script_dir/'modelsSea/model_edgetpu.tflite' # name of model
data_sea_dir = script_dir
label_sea_file = data_sea_dir/'labelsSea.txt' # Name of your label file

interpreter_sea = make_interpreter(f"{model_sea_file}")
interpreter_sea.allocate_tensors()

size = common.input_size(interpreter_sea)

#import the night model
model_night_file = script_dir/'modelsNight/model_edgetpu.tflite' # name of model
data_night_dir = script_dir
label_night_file = data_night_dir/'labelsNight.txt' # Name of your label file

interpreter_night = make_interpreter(f"{model_night_file}")
interpreter_night.allocate_tensors()

size = common.input_size(interpreter_night)


#run a loop for three hours
while (now_time < start_time + timedelta(minutes=178)):
    
    #enable the magnetometer
    sense.set_imu_config(True, True, True)

    #initialization of the magnetometer variables
    magnetometer_values = sense.get_compass_raw()
    mag_x, mag_y, mag_z = magnetometer_values['x'],magnetometer_values['y'],magnetometer_values['z']
    
    #coordinates of location on Earth below the ISS
    location = ISS.coordinates()
    
    #capture image
    image_file = f"{base_folder}/image/photo/photo_{counter:03d}.jpg"
    
    #define two variables for the models
    y = "notDefined"
    z = "notDefined"

    try:
        #capture the image
        capture(cam, image_file)
        
        #control of the first model (sea)
        image = Image.open(image_file).convert('RGB').resize(size, Image.ANTIALIAS)

        common.set_input(interpreter_sea, image)
        interpreter_sea.invoke()
        classes = classify.get_classes(interpreter_sea, top_k=1)

        labels = read_label_file(label_sea_file)
        
        y = labels.get(classes[0].id)

        if(y == "Sea"):
            #NDVI code
            contrasted = contrast_stretch(image)
            
            ndvi = calc_ndvi(contrasted)
            
            ndvi_contrasted = contrast_stretch(ndvi)
            cv2.imwrite(f"{base_folder}/image/ndvi_constrasted/ndvi_constrasted_{counter:03d}.jpg", ndvi_contrasted)

            #remove image
            os.remove(f"{base_folder}/image/photo/photo_{counter:03d}.jpg")
        

        #control of the second model (night)
        image = Image.open(image_file).convert('RGB').resize(size, Image.ANTIALIAS)

        common.set_input(interpreter_night, image)
        interpreter_night.invoke()
        classes = classify.get_classes(interpreter_night, top_k=1)

        labels = read_label_file(label_night_file)

        z = labels.get(classes[0].id)
        
    except Exception as e:
        #write a string in the file in case of error
        logger.error(f'{e._class.name_}: {e}')  
        


    #writes in the CSV file the obtained data
    data = (   
        counter,
        datetime.now(),
        location.latitude.degrees,
        location.longitude.degrees,
        mag_x,
        mag_y,
        mag_z, 
        z,
        y
    )
    #adds the data in the file
    add_csv_data(data_file, data) 

   
    #log event
    logger.info(f"iteration {counter}")
    counter += 1

    #the program takes a image every twelve seconds
    sleep(15)

    #update the current time
    now_time = datetime.now()





